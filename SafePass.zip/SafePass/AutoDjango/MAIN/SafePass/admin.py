from django.contrib import admin
from .models import Password

# How the models get registered 
admin.site.register(Password)