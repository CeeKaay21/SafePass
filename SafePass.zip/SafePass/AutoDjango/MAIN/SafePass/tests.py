from django.test import TestCase
from django.urls import reverse
from django.contrib.auth.models import User
from .models import Password

class PasswordVaultTestCase(TestCase):
#Creating a test user to simulate authentication 
    
    def setUp(self):
        self.user = User.objects.create_user(username='testuser', email='test@example.com', password='testpassword')
    
    def test_home_view(self):
        response = self.client.get(reverse('home'))
        self.assertEqual(response.status_code, 200)
        self.assertTemplateUsed(response, 'home.html')
    
    def test_signup_success(self):
        data = {
            'username': 'newuser',
            'email': 'newuser@example.com',
            'password': 'password',
            'password2': 'password'
        }
        response = self.client.post(reverse('home'), data=data, follow=True)
        self.assertRedirects(response, reverse('home'))
        self.assertContains(response, 'newuser. Thanks for Creating an account')
    
    def test_signup_password_mismatch(self):
        data = {
            'username': 'newuser',
            'email': 'newuser@example.com',
            'password': 'password',
            'password2': 'wrongpassword'
        }
        response = self.client.post(reverse('home'), data=data, follow=True)
        self.assertRedirects(response, reverse('home'))
        self.assertContains(response, 'Please make sure you&#x27;re using the correct Password')
    
#Creating a test user passwords not matching

def test_signup_passwords_do_not_match(self):
    # send a POST request with passwords that do not match
    response = self.client.post('/signup/', {
        'username': 'testuser',
        'email': 'testuser@example.com',
        'password': 'testpassword',
        'password2': 'wrongpassword',
    })
    # check that the response is a redirect back to the sign-up page
    self.assertRedirects(response, '/signup/')
    # check that the error message is displayed on the page
    self.assertContains(response, 'Please make sure you\'re using the correct Password')
    # check that the user was not created in the database
    self.assertFalse(User.objects.filter(username='testuser').exists())


