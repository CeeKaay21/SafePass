from django.urls import path
from .views import home

#Path has been defined to load the home.html in the http response method #

urlpatterns = [
    path("", home, name="home"),
]