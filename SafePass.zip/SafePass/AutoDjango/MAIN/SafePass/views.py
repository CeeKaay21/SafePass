
from django.contrib.auth.models import User
from django.shortcuts import render
from django.conf import settings
from django.contrib import messages
from django.http import HttpResponseRedirect
from django.contrib.auth import authenticate, login, logout
import random
from django.core.mail import send_mail
from cryptography.fernet import Fernet
from mechanize import Browser
import favicon
from .models import Password

br = Browser()
br.set_handle_robots(False)
fernet = Fernet(settings.KEY)

#in the event a new user signs up for the site the following infomation neefs to be obtained 
def home(request):
    if request.method == "POST":
        if "signup-form" in request.POST:
            username = request.POST.get("username")
            email = request.POST.get("email")
            password = request.POST.get("password")
            password2 = request.POST.get("password2")

#in the event the passwords are not identical to what was stated in the sign up process/ login
            if password != password2:
                msg = "Please make sure you're using the correct Password"
                messages.error(request, msg)
                return HttpResponseRedirect(request.path)
            
#in the event the username exists on the database already
            elif User.objects.filter(username=username).exists():
                msg = f"{username} already exists, please try another Username please"
                messages.error(request, msg)
                return HttpResponseRedirect(request.path)
            
#in the event the email exists on the database already
            elif User.objects.filter(email=email).exists():
                msg = f"{email} already exists, Please use an alternative choice please"
                messages.error(request, msg)
                return HttpResponseRedirect(request.path)
            else:
                User.objects.create_user(username, email, password)
                new_user = authenticate(request, username=username, password=password2)
                if new_user is not None:
                    login(request, new_user)
                    msg = f"{username}. Thanks for Creating an account"
                    messages.success(request, msg)
                    return HttpResponseRedirect(request.path)
                
#in the event the user logs out, the defined message should print  
        elif "logout" in request.POST:
            msg = f"{request.user}. You have successfully logged out, Goodbye :) "
            logout(request)
            messages.success(request, msg)
            return HttpResponseRedirect(request.path)
        
#Logic for allowing the user to log in
#in the event the user fails to login in, the defined message should print 
        elif 'login-form' in request.POST:
            username = request.POST.get("username")
            password = request.POST.get("password")
            new_login = authenticate(request, username=username, password=password)
            if new_login is None:
                msg = f"Login failed, Please make sure you enter the correct details"
                messages.error(request, msg)
                return HttpResponseRedirect(request.path)
#in the event the user enters the correct details the code will be sent to the user email box with the following message,
#"Django password Manager: confirm email,Your verification code is xxxxxx"
            else:
                code = str(random.randint(100000, 999999))
                global global_code
                global_code = code
                send_mail(
                    "SafePass: confirm email",
                    f"Your verification code is {code}.",
                    settings.EMAIL_HOST_USER,
                    [new_login.email],
                    fail_silently=False,
                )
                return render(request, "home.html", {
                    "code":code, 
                    "user":new_login,
                })
# From lines 70 - 84 states that in the event a returning user logs in the user will be sent a email verification code to their chosen signed up email
# From lines 87-93 basically prints an error message in the event the wrong code is used to login with
        elif "confirm" in request.POST:
            input_code = request.POST.get("code")
            user = request.POST.get("user")
            if input_code != global_code:
                msg = f"{input_code} is wrong!"
                messages.error(request, msg)
                return HttpResponseRedirect(request.path)
            else:
                login(request, User.objects.get(username=user))
                msg = f"{request.user} welcome again."
                messages.success(request, msg)
                return HttpResponseRedirect(request.path)
        
        elif "add-password" in request.POST:
            url = request.POST.get("url")
            email = request.POST.get("email")
            password = request.POST.get("password")

#ecrypts the data entered to the SQLlite database
            encrypted_email = fernet.encrypt(email.encode())
            encrypted_password = fernet.encrypt(password.encode())

#Obtains the URL of the entered website 
            try:
                br.open(url)
                title = br.title()
            except:
                title = url
                
#Obtains the logo's URL of website entered into the vault
            try:
                icon = favicon.get(url)[0].url
#Supplies a failed image if application cannot locate image from url
            except:
                icon = "https://thumbs.dreamstime.com/b/not-available-stamp-seal-watermark-distress-style-designed-rectangle-circles-stars-black-vector-rubber-print-title-138796185.jpg"

#Saves the data in database
            new_password = Password.objects.create(
                user=request.user,
                name=title,
                logo=icon,
                email=encrypted_email.decode(),
                password=encrypted_password.decode(),
            )
            msg = f"{title} added successfully."
            messages.success(request, msg)
            return HttpResponseRedirect(request.path)
        
#On user click in the event delete key is selected that data will be deleted from the vault
        elif "delete" in request.POST:
            to_delete = request.POST.get("password-id")
            msg = f"{Password.objects.get(id=to_delete).name} deleted."
            Password.objects.get(id=to_delete).delete()
            messages.success(request, msg)
            return HttpResponseRedirect(request.path)
         
    context = {}
    if request.user.is_authenticated:
        passwords = Password.objects.all().filter(user=request.user)
        for password in passwords:
            password.email = fernet.decrypt(password.email.encode()).decode()
            password.password = fernet.decrypt(password.password.encode()).decode()
        context = {
            "passwords":passwords,
        }   



    return render(request, "home.html", context)
