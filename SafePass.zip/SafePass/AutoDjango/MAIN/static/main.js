
//The display  modal on click function, basically showcase the defined models in my home.html

const modalWrapper = document.querySelector(".modals-wrapper");
if (modalWrapper){
    function displayModal(id){
        const modal = document.getElementById(id);
        modalWrapper.style.display = "flex";
        modal.style.display = "flex";
        
//The close modal function, basiscally on the event that user clicks out of a selected model that model will in fact close
        const close = document.getElementById("close-modal");
        close.addEventListener("click", () =>{
            modalWrapper.style.display = "none";
            modal.style.display = "none";
     
        document.querySelector("header").style.display = "unset";
        })

       
        document.querySelector("header").style.display = "none";
    }
}

//The copy to clipboard function, basically allows the user to copy their entered infomation to their respectful keyboard
const copies = document.querySelectorAll(".copy");
copies.forEach(copy =>{
    copy.onclick = () =>{
        let elemntToCopy = copy.previousElementSibling;
        elemntToCopy.select();
        document.execCommand("copy");
    }
})
// this code provides a simple way to show and hide links in response to a user action. 
// it displays the links for 3 seconds before hiding them again.
const actions = document.querySelectorAll(".actions");
if (actions){
    actions.forEach(action =>{
        action.onclick = () =>{
            const links = action.querySelectorAll("a");
            links.forEach(link =>{
                link.style.display = "flex";
            })
            setTimeout(function(){
                links.forEach(link =>{
                    link.style.display = "none";
                })}
            , 3000)
        }
    })
}