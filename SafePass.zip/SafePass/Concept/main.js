//The display  model on click function, basically showcase the defined models in my home.html

const modelWrapper = document.querySelector(".models-wrapper");
if (modelWrapper){
    function displaymodel(id){
        const model = document.getElementById(id);
        modelWrapper.style.display = "flex";
        model.style.display = "flex";
        
//The close model function, basiscally on the event that user clicks out of a selected model that model will in fact close
        const close = document.getElementById("close-model");
        close.addEventListener("click", () =>{
            modelWrapper.style.display = "none";
            model.style.display = "none";
     
        document.querySelector("header").style.display = "unset";
        })

       
        document.querySelector("header").style.display = "none";
    }
}

//The copy to clipboard function, basically allows the user to copy their entered infomation to their respectful keyboard
const copies = document.querySelectorAll(".copy");
copies.forEach(copy =>{
    copy.onclick = () =>{
        let elemntToCopy = copy.previousElementSibling;
        elemntToCopy.select();
        document.execCommand("copy");
    }
})

const actions = document.querySelectorAll(".actions");
if (actions){
    actions.forEach(action =>{
        action.onclick = () =>{
            const links = action.querySelectorAll("a");
            links.forEach(link =>{
                link.style.display = "flex";
            })
            setTimeout(function(){
                links.forEach(link =>{
                    link.style.display = "none";
                })}
            , 3000)
        }
    })
}